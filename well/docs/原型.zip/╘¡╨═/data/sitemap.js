﻿var sitemap = 

(function() {
    var _ = function() { var r={},a=arguments; for(var i=0; i<a.length; i+=2) r[a[i]]=a[i+1]; return r; }
    var _creator = function() { return _(b,[_(c,d,e,f,g,h,i,[_(c,j,e,f,g,k),_(c,l,e,f,g,m),_(c,n,e,f,g,o,i,[_(c,p,e,f,g,q),_(c,r,e,f,g,s),_(c,t,e,f,g,u),_(c,v,e,f,g,w),_(c,x,e,f,g,y),_(c,z,e,f,g,A),_(c,B,e,f,g,C)]),_(c,D,e,f,g,E,i,[_(c,F,e,f,g,G),_(c,H,e,f,g,I),_(c,J,e,f,g,K),_(c,L,e,f,g,M),_(c,N,e,f,g,O),_(c,P,e,f,g,Q)]),_(c,R,e,f,g,S,i,[_(c,T,e,f,g,U),_(c,V,e,f,g,W)])])]);}; 
var b="rootNodes",c="pageName",d="Home",e="type",f="Wireframe",g="url",h="Home.html",i="children",j="注册",k="注册.html",l="个人信息维护",m="个人信息维护.html",n="球员",o="球员.html",p="查看个人信息（包含编辑，修改）",q="查看个人信息（包含编辑，修改）.html",r="根据时间查看空闲可预约的球场信息",s="根据时间查看空闲可预约的球场信息.html",t="查看球队信息",u="查看球队信息.html",v="查看球队详细信息",w="查看球队详细信息.html",x="创建，编辑球队",y="创建，编辑球队.html",z="查看最近所有比赛",A="查看最近所有比赛.html",B="查看商品，服务",C="查看商品，服务.html",D="球队队长",E="球队队长.html",F="查看约战信息",G="查看约战信息.html",H="约战记录",I="约战记录.html",J="发布约战信息",K="发布约战信息.html",L="球队信息维护",M="球队信息维护.html",N="球队成员审核",O="球队成员审核.html",P="球队成员维护",Q="球队成员维护.html",R="老板",S="老板.html",T="发布场地信息",U="发布场地信息.html",V="发布商品服务信息",W="发布商品服务信息.html";
return _creator();
})();

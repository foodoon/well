﻿for(var i = 0; i < 25; i++) { var scriptId = 'u' + i; window[scriptId] = document.getElementById(scriptId); }

$axure.eventManager.pageLoad(
function (e) {

});
gv_vAlignTable['u12'] = 'top';gv_vAlignTable['u4'] = 'top';gv_vAlignTable['u8'] = 'top';gv_vAlignTable['u10'] = 'top';gv_vAlignTable['u22'] = 'top';gv_vAlignTable['u14'] = 'top';gv_vAlignTable['u20'] = 'top';gv_vAlignTable['u16'] = 'top';gv_vAlignTable['u6'] = 'top';gv_vAlignTable['u2'] = 'top';gv_vAlignTable['u24'] = 'top';gv_vAlignTable['u18'] = 'top';